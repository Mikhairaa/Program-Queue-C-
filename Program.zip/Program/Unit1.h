//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *Stok;
        TGroupBox *Pesan;
        TButton *Tambah;
        TListBox *ListBox1;
        TLabel *Kecil;
        TLabel *Sedang;
        TLabel *Besar;
        TEdit *Edit2;
        TEdit *Edit3;
        TEdit *Edit4;
        TLabel *x5;
        TLabel *x10;
        TLabel *x20;
        TEdit *Edit5;
        TEdit *Edit6;
        TEdit *Edit7;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *Edit8;
        TLabel *Label3;
        TButton *Clear;
        TButton *Hitung;
        TButton *Proses;
        TEdit *Edit9;
        TButton *Reset;
        TEdit *Edit1;
        TEdit *Edit10;
        TButton *OPEN;
        TButton *Button1;
        TLabel *Label4;
        void __fastcall TambahClick(TObject *Sender);
        void __fastcall ResetClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall OPENClick(TObject *Sender);
        void __fastcall HitungClick(TObject *Sender);
        void __fastcall ClearClick(TObject *Sender);
        void __fastcall ProsesClick(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
