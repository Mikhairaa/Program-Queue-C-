//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//deklarasi variabel global
int input,input2;
int ambil [100],x,n;
int a,kecil,sedang,besar,jmlkecil,jmlsedang,jmlbesar,hitung,proses,bunga;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TambahClick(TObject *Sender)
{
input = StrToInt (Edit1->Text);  //inputan pada Edit 1 diubah tipe datanya menjadi integer kemudian dimasukkan ke variabel input
ambil [x]=input;
ListBox1->Items->Clear() ;
Edit1->Clear();
Edit1->SetFocus();

for (int j =0; j<=x; j++)
        {
        ListBox1->Items->Add (ambil [j]);
        }

x++;n++; // indeks x dan jumlah elemen n bertambah

a=a+input; //variabel a merupakan total jumlah bunga mawar yang telah dipetik
Edit10->Text=a;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ResetClick(TObject *Sender)
{
kecil,sedang,besar=0;
Edit2->Text=kecil;
Edit3->Text=sedang;
Edit4->Text=besar;
OPEN->Enabled=true;
Edit1->Enabled=true;
Tambah->Enabled=true;

for (int j =0; j<=x; j++)
        {
        ambil [j]=NULL;  //data pada array ambil [j] dibersihkan
        }
x=0;n=0;   //inisisaliasi nilai variabel x dan n= 0

Edit1->Clear();
ListBox1->Clear();
Edit2->Clear();
Edit3->Clear();
Edit4->Clear();
Edit5->Clear();
Edit6->Clear();
Edit7->Clear();
Edit8->Clear();
Edit9->Clear();
Edit10->Clear();
a=0;
proses=0;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
Edit2->Enabled =false;
Edit3->Enabled =false;
Edit4->Enabled =false;
Edit5->Enabled =false;
Edit6->Enabled =false;
Edit7->Enabled =false;
Edit8->Enabled =false;
Edit9->Enabled =false;
Edit10->Enabled=false;
Hitung->Enabled=false;
Clear->Enabled=false;
Proses->Enabled=false;

kecil=0;sedang=0;besar=0;
Edit2->Text=kecil;
Edit3->Text=sedang;
Edit4->Text=besar;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OPENClick(TObject *Sender)
{
if (a<300)
        {
        ShowMessage("Stok <300. Tambah stok terlebih dahulu!");
        Edit1->SetFocus();
        }
else
        {
        Edit2->Enabled =true;
        Edit3->Enabled =true;
        Edit4->Enabled =true;
        Hitung->Enabled=true;
        Clear->Enabled=true;
        Edit1->Enabled=false;
        OPEN->Enabled=false;
        Tambah->Enabled=false;
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::HitungClick(TObject *Sender)
{
kecil=StrToInt(Edit2->Text);
sedang=StrToInt (Edit3->Text);
besar=StrToInt (Edit4->Text);

jmlkecil=kecil*5;  //nilai dari variabel kecil dikalikan 5 kemudian dimasukkan ke variabel jmlkecil
jmlsedang=sedang*10;
jmlbesar=besar*20;
hitung=jmlkecil+jmlsedang+jmlbesar;

Edit5->Text=jmlkecil;
Edit6->Text=jmlsedang;
Edit7->Text=jmlbesar;
Edit8->Text=hitung;

Edit2->Enabled =false;
Edit3->Enabled =false;
Edit4->Enabled =false;
Edit4->Enabled =false;
Edit6->Enabled =false;
Edit7->Enabled =false;
Edit8->Enabled =false;
Edit9->Enabled =false;
Proses->Enabled=true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ClearClick(TObject *Sender)
{
Edit2->Clear();
Edit3->Clear();
Edit4->Clear();
Edit5->Clear();
Edit6->Clear();
Edit7->Clear();
Edit8->Clear();

Edit2->Enabled =true;
Edit3->Enabled =true;
Edit4->Enabled =true;

kecil=0;sedang=0;besar=0;jmlkecil=0;jmlsedang=0;jmlbesar=0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ProsesClick(TObject *Sender)
{
input2=StrToInt(Edit8->Text);
bunga=StrToInt (Edit10->Text);

if (input2>bunga)
        {
        ShowMessage("Maaf, Bunga tidak cukup");
        Proses->Enabled=false;
        }
else
        {
        Proses->Enabled=true;
        Edit9->Enabled=true;

        proses=proses+input2;
        Edit9->Text= proses;

        bunga=bunga-input2;
        Edit10->Text=bunga;

        while (input2 >= ambil [0]) //perulangan terjadi selama input2 besar sama dengan array ambil indeks ke nol
        {
        input2=input2 - ambil [0];
        int i=1;
        ListBox1->Items->Clear();
                while (i < n)
                {
                ambil[i-1] = ambil[i];
                i=i+1; //jika perulangan terpenuhi maka increment i
                }
        n=n - 1; //jika perulangan tidak terpenuhi maka decrement n
        }

        if (input2<ambil[0])
                {
                ambil[0]=ambil[0]-input2;
                }
        ListBox1->Clear();
        int i=0;

        while (i<n)
                {
                 ListBox1->Items->Add(ambil[i]) ;
                 i=i+1;
                }
        }
}
//---------------------------------------------------------------------------
//Button CLose
void __fastcall TForm1::Button1Click(TObject *Sender)
{
        Application->Terminate();
}
//---------------------------------------------------------------------------



